
package employee.management.system;
import javax.swing.*;

public class Main_class extends JFrame {
    Main_class() {
        setSize(500,500);
        setVisible(true);
    }
    public static void main(String args[]){
        new Main_class();
    }
}

